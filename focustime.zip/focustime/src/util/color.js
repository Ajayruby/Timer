export const colors ={

  darkBlue : "#252250",
  white:"#FFFFFF",
  hexa: "#25345A",
}