import React from 'react';
import {
  View,
  SafeAreaView,
  FlatList,
  Text,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { RoundedButton } from '../../component/RoundedButton';
import { Colors } from '../../util/color';
import { spacing, fontsizes } from '../../util/sizes';
const HistoryItem = ({ item, index }) => {
  return (
    <Text
      style={{
        color: 'red',
        fontWeight: 'bold',
        fontSize: 30,
        paddingTop: 10,
      }}>
      {item.subject}
    </Text>
  );
};
export const FocusHistory = ({ focusHistory, onClear }) => {
  const clearHistory = () => {
    onClear();
  };

  return (
    <>
      <SafeAreaView style={{ flex: 0.5, alignItems: 'center' }}>
        {!!focusHistory.length && (
          <>
            <Text style={styles.title}>This we've focus on</Text>
            <ScrollView style={styles.scrollView}>
              <FlatList
                style={styles.flatitem}
                contentContainerStyle={{ flex: 1, alignItems: 'center' }}
                data={focusHistory}
                renderItem={HistoryItem}
              />
            </ScrollView>
            <View style={styles.clearButton}>
              <RoundedButton
                size={75}
                title="clear"
                onPress={() => onClear()}
              />
            </View>
          </>
        )}
      </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  historyItem: (status) => ({
    color: status > 1 ? 'red' : 'blue',
  }),

  title: {
    color: 'white',
    fontSize: 16,
  },
  clearButton: {
    alignItems: 'center',
    padding: 10,
  },
  scrollView: {
    marginHorizontal: 20,
  },

  flatitem: {
    textAlign: 'center',
    flex: 1,
  },
});
