import React,{useState} from 'react';
import { RoundedButton } from '../../component/RoundedButton';

import { View, Text, StyleSheet } from 'react-native';
import { TextInput } from 'react-native-paper';
import {spacing,fontsizes} from '../../util/sizes';
import {colors} from '../../util/color';

export const Focus = ({addSubject}) => {

  const [temItem,setTempItem] = useState()
  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Text style={styles.title}> what would like to focus on?</Text>
        <View style={styles.inputContainer}>
          <TextInput style={styles.inputfield} onSubmitEditing = {

            ({nativeEvent})=>{
              setTempItem(nativeEvent.text)
            }

          }
            />
          <RoundedButton size={50} title="+" style={{backgroundColor:"#4A235A"}} onPress = {()=>{addSubject(temItem)}} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.xxl,
  },

  titleContainer: {
    flex: 0.5,
    padding: spacing.md,
    justifyContent: 'center',
  },
  title: {
    color: colors.white,
    fontSize: fontsizes.md,
    fontWeight: 'bold',
  },
  inputContainer: {
    paddingTop: spacing.md,
    flexDirection: 'row',
    alignItems:"center"
  },
  inputfield: {
    flex:1,
    marginRight: spacing.sm,
  },
});
