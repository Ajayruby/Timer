import React,{useState} from 'react';
import { View, Text, StyleSheet,Vibration,Platform } from 'react-native';
import { spacing, paddingsizes } from '../../util/sizes';
import { colors } from '../../util/color';
import { RoundedButton } from '../../component/RoundedButton';
import {Timing} from "./Timing";
import { Countdown } from '../../component/Countdown';
import {ProgressBar} from 'react-native-paper';
import {useKeepAwake} from "expo-keep-awake"

export const Timer = ({ focusSubject,onTimerEnd,clearSubject }) => {
  useKeepAwake()
  const [minutes,setMinutes] = useState(0.1)
  const [isStarted,setIsStarted] = useState(false);
  const [progress,setProgress] = useState(1);
  const changeTime = (min)=>{
    setMinutes(min)
    setProgress(1);
    setIsStarted(false)
  }
  const onProgress = (progress)=>{
    setProgress(progress)
  }
  const onEnd = ()=>{
    vibrate()
    setMinutes(0.1)
    setProgress(1);
    setIsStarted(false);
    onTimerEnd()
  }
  const vibrate=()=>{
    if(Platform.OS === 'ios'){
      const intervel = setInterval(()=>{
        Vibration.vibrate(),1000
      })
      setTimeout(()=>{clearInterval(intervel),10000})
    }
    else{
      Vibration.vibrate(10000)

    }
  }
  return (
    <View style={styles.container}>
    <View style={styles.countdown}>
      <Countdown isPaused = {!isStarted} onProgress={onProgress} minutes={minutes} onEnd={onEnd} />
    </View>
    <View style ={{paddingTop:spacing.lg}}>
        <Text style={styles.text}>Focusing on: </Text>
        <Text style={styles.task}> {focusSubject}</Text>
    </View>
    <View style ={{paddingTop:10}}>
    <ProgressBar 
    color="#5e84e2"
    style={{height:10}}
    progress = {progress}

    />
    </View>
    <View style = {styles.buttonwapper}>
    <Timing onChangeTime = {changeTime}/>
    </View>
    <View style = {styles.buttonwapper}>
      {isStarted?(<RoundedButton title= "off" size={75} style={{backgroundColor:"red"}} onPress ={()=>setIsStarted(false)}/>):
    (<RoundedButton title= "on" size={75} style={{backgroundColor:"green"}} onPress ={()=> setIsStarted(true)}/>)}
    <View style= {styles.clear}>
   <RoundedButton title= "<-" size={50} style={{backgroundColor:"#16A085"}} onPress ={()=> clearSubject()}/>
   </View>
   </View>
   
    </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  text: {
    color: colors.white,
    textAlign: 'center',
  },
  task: {
    color: colors.white,
    fontWeight: 'bold',
    textAlign:"center"
  },
  countdown:{
    flex:0.5,
    alignItems:"center",
    justifyContent:"center",
    paddingTop:spacing.lg
  },
  buttonwapper:{
    flex:0.3,
    flexDirection:'row',
    paddingTop:15,
    justifyContent:"center",
    alignItems:"center",
    fontSize:10,
    fontWeight:"bold"

  },

  clear:{
    paddingLeft:5,
    fontWeight:"bold"
  }

  

  
});
