import React from 'react';

import {TouchableOpacity,Text,StyleSheet} from 'react-native';

export const RoundedButton = ({
  style = {},
  textstyle = {},
  size = 125,
  ...props
})=>{
  return(
    <TouchableOpacity style = {[styles(size).radius,style]}>
    <Text style = {[styles(size).text,style]} onPress={props.onPress}>
    {props.title}

    </Text>
    </TouchableOpacity>
  )
}

const styles= (size) => StyleSheet.create({
  radius:{
    borderRadius:size/4,
    width:size,
    height:size,
    textAlign:"center",
    borderWidth:2,
    borderColor:'white',
      
  },

  text:{
    color:'white',
    fontSize:size/3,
    textAlign:"center",
    marginTop: 10,
    fontWeight:"bold",

  }
})