import React, {useState,useEffect} from 'react';
import {Text,StyleSheet,View} from 'react-native';
import {spacing,fontsizes} from '../util/sizes';
import {colors} from '../util/color';
const minutesToMillis = (minutes)=>minutes*1000*60;
const formatTime =(time)=> time<10?`0${time}`:time;
export const Countdown = ({

  minutes=1,
  isPaused,
  onProgress,
  onEnd
  
}) =>{
  const intervel = React.useRef(null);
  const countDown=()=>{
    setMills((time)=>{
      if(time===0){
        clearInterval(intervel.current);
        onEnd();
        return time
      }
      const timeLeft = time-1000
      onProgress(timeLeft/minutesToMillis(minutes))
      return timeLeft

    })
  }
useEffect(()=>{
  setMills(minutesToMillis(minutes))

},[minutes])

  useEffect(()=>{
    if(isPaused){
      if(intervel.current) clearInterval(intervel.current)
      return;
    }
      intervel.current= setInterval(countDown,1000);
      return()=>clearInterval(intervel.current);

  },[isPaused])

  const [mills,setMills] = useState(null);
  const minute = Math.floor(mills/1000/60)%60;
  const seconds = Math.floor(mills/1000)%60
  return(
    <Text style = {styles.text}>{formatTime(minute)}:{formatTime(seconds)}</Text>
  )
}

const styles= StyleSheet.create({

  text:{
    fontSize: fontsizes.xxxl,
    color:colors.white,
    padding: spacing.md,
    backgroundColor: colors.hexa
  }

})