import React, { useState,useEffect } from 'react';
import { Text, View, StyleSheet, Platform} from 'react-native';

import { Focus } from './src/feature/focus/focus';
import Constants from 'expo-constants';
import { spacing, paddingsizes } from './src/util/sizes';
import { colors } from './src/util/color';
import { Timer } from './src/feature/timer/Timer';
import {FocusHistory} from "./src/feature/focus/FocusHistory";
const STATUSES = {
  COMPLETE:1,
  CANCLE:2
}


export default function App() {
  const [focusSubject, setFocusSubject] = useState(null);
  const [focusHistory,setFoucusHistory] = useState([]);
  const addFocusHistorySubjectWithState = (subject,status)=>{
    setFoucusHistory([...focusHistory,{subject,status}])
  }
const onClear=()=>{
  setFoucusHistory({});
}

const saveFocusHistory = async ()=>{
  try{
    await AsyncStorage.setItem('focusHistory',JSON.stringify(focusHistory))
  }catch(e){
    console.log(e)
  }
};

const loadFocusHistory = async()=>{
  try{
    const history = await AsyncStorage.getItem('focusHistory')
    if(history&& JSON.parse(history).length){
      setFoucusHistory(JSON.parse(history))
    }

  }catch(e){
    console.log(e)
  }
};

useEffect(()=>{
  loadFocusHistory();
},[])

useEffect(()=>{
  saveFocusHistory();
},[focusHistory])

  return (
    
    <View style={styles.container}>
    
      {focusSubject ? (
        <Timer focusSubject={focusSubject} onTimerEnd={()=>{
          setFocusSubject(null)
          addFocusHistorySubjectWithState(focusSubject,STATUSES.COMPLETE)

        }} clearSubject={()=>{
        setFocusSubject(null),
        addFocusHistorySubjectWithState(focusSubject,STATUSES.CANCLE)
        }}
         />
      ) : (
        <>
        <Focus addSubject={setFocusSubject} />
        <FocusHistory focusHistory={focusHistory} onClear={onClear}/>

        </>
      )}
      
    
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === 'ios' ? spacing.sm : spacing.lg,
    backgroundColor: colors.darkBlue,
  },
});
